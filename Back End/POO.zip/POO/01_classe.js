//criando a primeira classe
class pessoa{
    //atributos
    nome;
    idade;
}

//criando um novo objeto(instancia)
const pessoa1 = new pessoa();
console.log(pessoa1);

//aplicando valores aos atributos
pessoa1.nome = "Vitor";
pessoa1.idade = 16;
console.log(pessoa1);

const pessoa2 = new pessoa();
pessoa2.nome = "Mustang"
pessoa2.idade = 1964
console.log(pessoa2);