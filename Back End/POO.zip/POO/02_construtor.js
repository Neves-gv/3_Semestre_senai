//criando a primeira classe
class pessoa{
    //criando o metado construtor
    constructor(nome, idade){

        //atributos
        this.nome = nome;
        this.idade = idade;
    }
}
const pessoa1 = new pessoa("cladia", 25);
console.log(pessoa1);
const pessoa2 = new pessoa("Barreto", 30);